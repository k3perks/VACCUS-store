# VACCUS Drop 001

This version is the upgraded Gen Z / premium streetwear storefront.

Features:
- Aggressive black editorial design
- Neon acid-lime accent
- Animated-feeling ticker and hover interactions
- VACCUS hero section
- Your Starfall Jacket image
- Jacket price $60
- Hoodie price $100 marked Coming Soon
- Functional cart
- Stripe Checkout for card payments
- US shipping address collection
- Mobile responsive
- Success page

Run:
1. Install Node.js 20+
2. `npm install`
3. Copy `.env.example` to `.env`
4. Add your Stripe secret key
5. `npm start`
6. Open http://localhost:4242

For real payments, connect and verify your bank account in Stripe, then use your live Stripe key after testing.
Never expose STRIPE_SECRET_KEY in public frontend code.
