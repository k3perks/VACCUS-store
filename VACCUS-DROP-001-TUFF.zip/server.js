import express from "express";
import dotenv from "dotenv";
import Stripe from "stripe";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PRODUCTS = {
  jacket: { name: "Starfall Jacket", price: 6000, image: "/images/vaccus-jacket.png" }
};

app.post("/api/create-checkout-session", async (req, res) => {
  try {
    if (!process.env.STRIPE_SECRET_KEY) {
      return res.status(500).json({ error: "Stripe isn't connected yet. Add STRIPE_SECRET_KEY to .env." });
    }
    const items = Array.isArray(req.body.items) ? req.body.items : [];
    const line_items = [];
    for (const item of items) {
      const p = PRODUCTS[item.id];
      if (!p) continue;
      const quantity = Math.max(1, Math.min(10, Number(item.quantity) || 1));
      line_items.push({
        price_data: {
          currency: "usd",
          product_data: { name: p.name, images: [`${process.env.BASE_URL}${p.image}`] },
          unit_amount: p.price
        },
        quantity
      });
    }
    if (!line_items.length) return res.status(400).json({ error: "Your bag is empty." });

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items,
      billing_address_collection: "required",
      shipping_address_collection: { allowed_countries: ["US"] },
      customer_creation: "always",
      allow_promotion_codes: true,
      success_url: `${process.env.BASE_URL}/success.html`,
      cancel_url: `${process.env.BASE_URL}/#drop`
    });
    res.json({ url: session.url });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Checkout couldn't start." });
  }
});

app.listen(process.env.PORT || 4242, () =>
  console.log(`VACCUS live at http://localhost:${process.env.PORT || 4242}`)
);
